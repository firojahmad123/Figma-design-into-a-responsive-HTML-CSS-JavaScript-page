# landing page 
 figma to html conversion(desktop version)

html, css, javascript, owl carousel,
footer ,slider,overlay,navbar,contact form,flexbox
![screencapture-127-0-0-1-5500-index-html-2022-11-10-01_50_28](https://user-images.githubusercontent.com/95566104/200939071-d7579b40-4366-4744-9a07-502783e7c48b.png)

